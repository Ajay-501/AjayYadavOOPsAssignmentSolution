package department.hrdepartment.modal;

import departments.superdepartment.modal.Super_department;

public class Hr_department extends Super_department {
	
	private String departmentNameAdmin = "HR";
	
	public String departmentName() {
		return "Welcome to " + departmentNameAdmin + " Department";
	}
	
	public String getTodaysWork() {
		return "Fill today�s timesheet and mark your attendance";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
	
	public String doActivity() {
		return "team Lunch";
	}
}


