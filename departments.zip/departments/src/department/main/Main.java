package department.main;

import department.admindepartment.modal.Admin_department;
import department.hrdepartment.modal.Hr_department;
import department.techdepartment.modal.Tech_department;

public class Main {

	public static void main(String[] args) {
		
		Admin_department adminDep = new Admin_department();
		Hr_department hrDep = new Hr_department();
		Tech_department techDep = new Tech_department();
		
		System.out.println(adminDep.departmentName()); 
		System.out.println(adminDep.getTodaysWork()); 
		System.out.println(adminDep.getWorkDeadline());
		System.out.println(adminDep.isTodayAHoliday());
		
		System.out.println();
		
		System.out.println(hrDep.departmentName());
		System.out.println(hrDep.doActivity());
		System.out.println(hrDep.getTodaysWork()); 
		System.out.println(hrDep.getWorkDeadline());
		System.out.println(hrDep.isTodayAHoliday());
		
		System.out.println();
		
		System.out.println(techDep.departmentName());
		System.out.println(techDep.getTodaysWork()); 
		System.out.println(techDep.getWorkDeadline());
		System.out.println(techDep.getTechStackInformation());
		System.out.println(techDep.isTodayAHoliday());
	}

}
