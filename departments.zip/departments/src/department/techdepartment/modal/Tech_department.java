package department.techdepartment.modal;

import departments.superdepartment.modal.Super_department;

public class Tech_department extends Super_department {
	
	private String departmentNameAdmin = "Tech";
	
	public String departmentName() {
		return "Welcome to " + departmentNameAdmin + " Department";
	}
	
	public String getTodaysWork() {
		return "Complete coding of module 1";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
	
	public String getTechStackInformation() {
		return "Core Java";
	}
}
