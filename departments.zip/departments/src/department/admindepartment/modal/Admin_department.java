package department.admindepartment.modal;

import departments.superdepartment.modal.Super_department;

public class Admin_department extends Super_department {
	
	private String departmentNameAdmin = "Admin";
	
	public String departmentName() {
		return "Welcome to " + departmentNameAdmin + " Department";
	}
	
	public String getTodaysWork() {
		return "Complete your documents Submission";
	}
	
	public String getWorkDeadline() {
		return "Complete by EOD";
	}
}
