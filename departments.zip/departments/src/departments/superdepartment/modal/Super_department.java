package departments.superdepartment.modal;

public class Super_department {
	
	private String superDepName = "Super Department";
	private String superTodayWork = "No Work as of now";
	private String superWorkDeadline = "Nil";
	private String isTodayAHoliday = "Today is not a holiday";
	
	public String departmentName() {
		return superDepName;
	}
	
	public String getTodaysWork() {
		return superTodayWork;
	}
	
	public String getWorkDeadline() {
		return superWorkDeadline;
	}
	
	public String isTodayAHoliday() {
		return isTodayAHoliday;
	}
}
